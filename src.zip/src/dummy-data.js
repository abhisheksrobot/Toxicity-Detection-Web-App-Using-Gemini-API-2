/**
 * This file contains the helper function and dummy data
 * used to pre-populate the extension on first install.
 * It is imported by background.js.
 */

/**
 * Helper function to create dummy timestamps.
 * @param {number} daysAgo - How many days in the past.
 * @param {number} hour - The hour of the day (0-23). If null, uses 1 hour ago.
 * @returns {string} - An ISO 8601 timestamp string.
 */
function getDummyTimestamp(daysAgo, hour) {
    const now = new Date();

    // --- NEW: Handle "1 hour ago" case ---
    if (daysAgo === 0 && (hour === undefined || hour === null)) {
        now.setHours(now.getHours() - 1);
        return now.toISOString();
    }
    // --- End new case ---

    now.setDate(now.getDate() - daysAgo);
    now.setHours(hour, 0, 0, 0); // Set a specific hour
    return now.toISOString();
}

/**
 * Generate realistic dummy data for first launch (20 entries).
 */
export const DUMMY_HISTORY = [
    // --- Original 8 Entries ---
    {
        "toxicity_score": 15, "classification": "Okay", "host": "google.com", "timestamp": getDummyTimestamp(0, null), // 1 hour ago
        "attributes": { "insult": 0, "threat": 0, "obscenity": 0, "identity_attack": 0, "sexually_explicit": 0 },
        "rationale": "Standard search page."
    },
    {
        "toxicity_score": 30, "classification": "Average", "host": "reddit.com", "timestamp": getDummyTimestamp(0, 2),
        "attributes": { "insult": 40, "threat": 10, "obscenity": 30, "identity_attack": 5, "sexually_explicit": 0 },
        "rationale": "Contains some average toxicity and insults."
    },
    {
        "toxicity_score": 55, "classification": "High", "host": "twitter.com", "timestamp": getDummyTimestamp(0, 9),
        "attributes": { "insult": 60, "threat": 20, "obscenity": 40, "identity_attack": 50, "sexually_explicit": 10 },
        "rationale": "High levels of insult and identity attacks detected."
    },
    {
        "toxicity_score": 78, "classification": "Worse", "host": "4chan.org", "timestamp": getDummyTimestamp(1, 14),
        "attributes": { "insult": 80, "threat": 40, "obscenity": 70, "identity_attack": 60, "sexually_explicit": 30 },
        "rationale": "Contains significant amounts of obscene and hateful content."
    },
    {
        "toxicity_score": 22, "classification": "Okay", "host": "youtube.com", "timestamp": getDummyTimestamp(1, 18),
        "attributes": { "insult": 10, "threat": 0, "obscenity": 30, "identity_attack": 5, "sexually_explicit": 0 },
        "rationale": "Mostly fine, with some mild obscenity in comments."
    },
    {
        "toxicity_score": 8, "classification": "Suitable", "host": "news.bbc.com", "timestamp": getDummyTimestamp(3, 8),
        "attributes": { "insult": 5, "threat": 0, "obscenity": 0, "identity_attack": 0, "sexually_explicit": 0 },
        "rationale": "Content is suitable for all audiences."
    },
    {
        "toxicity_score": 45, "classification": "Medium", "host": "imgur.com", "timestamp": getDummyTimestamp(5, 22),
        "attributes": { "insult": 50, "threat": 10, "obscenity": 30, "identity_attack": 40, "sexually_explicit": 5 },
        "rationale": "Contains a medium level of insults and identity-based jokes."
    },
    {
        "toxicity_score": 2, "classification": "Suitable", "host": "wikipedia.org", "timestamp": getDummyTimestamp(6, 12),
        "attributes": { "insult": 0, "threat": 0, "obscenity": 0, "identity_attack": 0, "sexually_explicit": 0 },
        "rationale": "Informational content, very low toxicity."
    },

    // --- 12 New Entries ---
    {
        "toxicity_score": 12, "classification": "Okay", "host": "nytimes.com", "timestamp": getDummyTimestamp(7, 9),
        "attributes": { "insult": 10, "threat": 5, "obscenity": 0, "identity_attack": 0, "sexually_explicit": 0 },
        "rationale": "Generally suitable news content."
    },
    {
        "toxicity_score": 65, "classification": "High", "host": "foxnews.com", "timestamp": getDummyTimestamp(8, 11),
        "attributes": { "insult": 50, "threat": 10, "obscenity": 20, "identity_attack": 70, "sexually_explicit": 5 },
        "rationale": "Comment section contains high identity attack language."
    },
    {
        "toxicity_score": 5, "classification": "Suitable", "host": "amazon.com", "timestamp": getDummyTimestamp(9, 15),
        "attributes": { "insult": 0, "threat": 0, "obscenity": 0, "identity_attack": 0, "sexually_explicit": 0 },
        "rationale": "Product listings are suitable."
    },
    {
        "toxicity_score": 18, "classification": "Okay", "host": "espn.com", "timestamp": getDummyTimestamp(10, 17),
        "attributes": { "insult": 20, "threat": 0, "obscenity": 10, "identity_attack": 5, "sexually_explicit": 0 },
        "rationale": "Mild insults in comments."
    },
    {
        "toxicity_score": 33, "classification": "Average", "host": "instagram.com", "timestamp": getDummyTimestamp(11, 20),
        "attributes": { "insult": 30, "threat": 5, "obscenity": 20, "identity_attack": 30, "sexually_explicit": 10 },
        "rationale": "Average toxicity found in comment sections."
    },
    {
        "toxicity_score": 90, "classification": "Extreme", "host": "stormfront.org", "timestamp": getDummyTimestamp(12, 10),
        "attributes": { "insult": 80, "threat": 70, "obscenity": 50, "identity_attack": 95, "sexually_explicit": 10 },
        "rationale": "Extreme levels of identity attack and threat."
    },
    {
        "toxicity_score": 28, "classification": "Average", "host": "facebook.com", "timestamp": getDummyTimestamp(14, 13),
        "attributes": { "insult": 30, "threat": 10, "obscenity": 20, "identity_attack": 25, "sexually_explicit": 5 },
        "rationale": "Contains average levels of arguments and insults."
    },
    {
        "toxicity_score": 3, "classification": "Suitable", "host": "github.com", "timestamp": getDummyTimestamp(15, 16),
        "attributes": { "insult": 0, "threat": 0, "obscenity": 0, "identity_attack": 0, "sexually_explicit": 0 },
        "rationale": "Technical content, very low toxicity."
    },
    {
        "toxicity_score": 48, "classification": "Medium", "host": "tiktok.com", "timestamp": getDummyTimestamp(18, 21),
        "attributes": { "insult": 40, "threat": 10, "obscenity": 50, "identity_attack": 30, "sexually_explicit": 20 },
        "rationale": "Medium levels of obscenity and insult."
    },
    {
        "toxicity_score": 10, "classification": "Suitable", "host": "linkedin.com", "timestamp": getDummyTimestamp(20, 9),
        "attributes": { "insult": 5, "threat": 0, "obscenity": 0, "identity_attack": 0, "sexually_explicit": 0 },
        "rationale": "Professional content, suitable."
    },
    {
        "toxicity_score": 38, "classification": "Medium", "host": "cnn.com", "timestamp": getDummyTimestamp(22, 8),
        "attributes": { "insult": 40, "threat": 5, "obscenity": 10, "identity_attack": 30, "sexually_explicit": 0 },
        "rationale": "Political commentary contains medium toxicity."
    },
    {
        "toxicity_score": 70, "classification": "High", "host": "dailymail.co.uk", "timestamp": getDummyTimestamp(25, 12),
        "attributes": { "insult": 60, "threat": 20, "obscenity": 40, "identity_attack": 70, "sexually_explicit": 10 },
        "rationale": "High levels of insult and identity attacks in comments."
    }
];

/**
 * Create the recentDomains object from the dummy history.
 */
export const DUMMY_RECENT_DOMAINS = {};
DUMMY_HISTORY.forEach(item => {
    if (!DUMMY_RECENT_DOMAINS[item.host] || new Date(item.timestamp) > new Date(DUMMY_RECENT_DOMAINS[item.host].timestamp)) {
        DUMMY_RECENT_DOMAINS[item.host] = item;
    }
});
