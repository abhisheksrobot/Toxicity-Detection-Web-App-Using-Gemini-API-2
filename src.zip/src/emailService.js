// Email service using Web3Forms (free email API)
const DEFAULT_EMAIL = {
  toEmail: 'falakpatel.fg@gmail.com',
  accessKey: '404899bc-17fb-43fe-bdfe-5ed7fa24ab65', // Web3Forms access key
};

export const sendEmail = async (templateParams) => {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get('emailSettings', async (result) => {
      const cfg = result.emailSettings || {};
      
      console.log('Email settings loaded:', { ...cfg, accessKey: cfg.accessKey ? '***' : 'not set' });

      if (cfg.emailAlertsEnabled === false) {
        console.log('Email alerts are disabled');
        resolve({ success: false, message: 'Email alerts disabled' });
        return;
      }

      const toEmail = cfg.toEmail || DEFAULT_EMAIL.toEmail;
      const accessKey = cfg.web3formsKey || DEFAULT_EMAIL.accessKey;

      if (!toEmail || !accessKey) {
        console.error('Email configuration incomplete. Please set email and access key in Setup tab.');
        resolve({ success: false, message: 'Configuration incomplete' });
        return;
      }

      try {
        console.log('Attempting to send email to:', toEmail);
        
        const formData = new FormData();
        formData.append('access_key', accessKey);
        formData.append('email', toEmail);
        formData.append('subject', templateParams.subject || 'Toxicity Alert');
        formData.append('message', templateParams.message || 'Toxicity alert triggered.');
        formData.append('name', 'Toxicity Detector Extension');

        const response = await fetch('https://api.web3forms.com/submit', {
          method: 'POST',
          body: formData,
        });
        
        const data = await response.json();
        console.log('Email send result:', data);
        
        if (data.success) {
          console.log('✅ Email sent successfully!');
          resolve({ success: true, message: 'Email sent' });
        } else {
          console.error('❌ Email send failed:', data.message);
          resolve({ success: false, message: data.message });
        }
      } catch (err) {
        console.error('❌ Email send error:', err);
        reject(err);
      }
    });
  });
};
