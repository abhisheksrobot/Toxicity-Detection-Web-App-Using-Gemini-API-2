import React, { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const AnalyticsTab = () => {
  const [pieData, setPieData] = useState([]);
  const [dailyData, setDailyData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Color mapping for classifications
  const getClassificationColor = (classification) => {
    const colorMap = {
      'Suitable': '#198754',
      'Okay': '#9AD91E',
      'Average': '#0D6EFD',
      'Medium': '#FFC107',
      'High': '#FD7E14',
      'Worse': '#DC3545',
      'Extreme': '#9163FF'
    };
    return colorMap[classification] || '#8884d8';
  };

  const CATEGORY_COLORS = {
    toxic: '#dc3545',
    severe_toxic: '#9163FF',
    obscene: '#ff8042',
    threat: '#fd7e14',
    insult: '#ffc107',
    identity_hate: '#6c757d',
    sexuality: '#e83e8c',
    violence: '#8b0000',
    terrorism: '#000000',
  };

  const CATEGORY_NAMES = {
    toxic: 'Toxic',
    severe_toxic: 'Severe Toxic',
    obscene: 'Obscene',
    threat: 'Threat',
    insult: 'Insult',
    identity_hate: 'Identity Hate',
    sexuality: 'Explicit Content',
    violence: 'Violence',
    terrorism: 'Terrorism',
  };

  useEffect(() => {
    setIsLoading(true);
    chrome.storage.local.get('history', (result) => {
      if (result.history && Array.isArray(result.history)) {
        const history = result.history;

        // Process pie data - count classifications with unique domain-score combinations
        const seenDomainScores = new Set();
        const pieData = history.reduce((acc, item) => {
          const uniqueKey = `${item.host}-${item.toxicity_score}`;
          if (!seenDomainScores.has(uniqueKey)) {
            seenDomainScores.add(uniqueKey);
            const existing = acc.find(d => d.name === item.classification);
            if (existing) {
              existing.value++;
            } else {
              acc.push({ name: item.classification, value: 1 });
            }
          }
          return acc;
        }, []);
        setPieData(pieData);

        // Process daily data - stacked bar by category
        const dailyData = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map(day => ({ 
          day, 
          toxic: 0, severe_toxic: 0, obscene: 0, threat: 0, insult: 0, identity_hate: 0, sexuality: 0, violence: 0, terrorism: 0, 
          count: 0 
        }));
        
        history.forEach(item => {
          const day = new Date(item.timestamp).getDay();
          const attrs = item.attributes || {};
          // Add each category value to the daily total
          const categories = ['toxic', 'severe_toxic', 'obscene', 'threat', 'insult', 'identity_hate', 'sexuality', 'violence', 'terrorism'];
          categories.forEach(key => {
            if (dailyData[day][key] !== undefined && attrs[key] !== undefined) {
              dailyData[day][key] += attrs[key];
            }
          });
          dailyData[day].count++;
        });

        // Average the daily data
        const avgData = dailyData.map(d => {
          const newD = { day: d.day };
          for (const key in d) {
            if (key !== 'day' && key !== 'count') {
              newD[key] = d.count > 0 ? parseFloat((d[key] / d.count).toFixed(1)) : 0;
            }
          }
          return newD;
        });
        console.log('Daily Data for Chart:', avgData);
        setDailyData(avgData);
      }
      setIsLoading(false);
    });
  }, []);

  if (isLoading) {
    return (
      <div style={{ textAlign: 'center', padding: '2rem' }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
        <p className="mt-2">Loading analytics data...</p>
      </div>
    );
  }

  return (
    <div>
      <div className="card mb-4">
        <div className="card-body">
          <h5 className="card-title">Content Distribution</h5>
          {pieData.length > 0 ? (
          <div style={{ width: '100%', display: 'flex', justifyContent: 'center', overflow: 'hidden', marginBottom: '1rem' }}>
            <div style={{ width: '350px', height: '300px' }}>
            <ResponsiveContainer width={350} height={300} minWidth={200} minHeight={200}>
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={getClassificationColor(entry.name)} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#ffffff', color: '#111827', border: '1px solid #e5e7eb' }} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
            </div>
          </div>
          ) : (
            <div style={{ padding: '2rem', textAlign: 'center', backgroundColor: '#f8f9fa', borderRadius: '8px' }}>
              <p className="text-muted">No content distribution data available yet.</p>
            </div>
          )}
        </div>
      </div>

      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Content Trend by Category (Daily Average)</h5>
          {dailyData.length > 0 && dailyData.some(d => Object.keys(d).some(k => k !== 'day' && d[k] > 0)) ? (
          <div style={{ width: '380px', height: '450px', margin: '0 auto' }}>
            <BarChart 
              width={380} 
              height={450} 
              data={dailyData} 
              margin={{ top: 20, right: 10, left: 10, bottom: 80 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis 
                dataKey="day" 
                tick={{ fill: '#111827', fontSize: 10 }}
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis 
                tick={{ fill: '#111827', fontSize: 10 }}
                label={{ value: 'Toxicity %', angle: -90, position: 'insideLeft', style: { fill: '#111827', fontSize: 11 } }}
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#ffffff', color: '#111827', border: '1px solid #e5e7eb' }}
                formatter={(value, name) => [(value || 0).toFixed(1) + '%', CATEGORY_NAMES[name] || name]}
              />
              <Legend 
                wrapperStyle={{ paddingTop: '10px', fontSize: '11px' }}
                formatter={(value) => CATEGORY_NAMES[value] || value}
                iconType="square"
                iconSize={10}
              />
              <Bar dataKey="toxic" stackId="a" fill={CATEGORY_COLORS.toxic} />
              <Bar dataKey="severe_toxic" stackId="a" fill={CATEGORY_COLORS.severe_toxic} />
              <Bar dataKey="obscene" stackId="a" fill={CATEGORY_COLORS.obscene} />
              <Bar dataKey="threat" stackId="a" fill={CATEGORY_COLORS.threat} />
              <Bar dataKey="insult" stackId="a" fill={CATEGORY_COLORS.insult} />
              <Bar dataKey="identity_hate" stackId="a" fill={CATEGORY_COLORS.identity_hate} />
              <Bar dataKey="sexuality" stackId="a" fill={CATEGORY_COLORS.sexuality} />
              <Bar dataKey="violence" stackId="a" fill={CATEGORY_COLORS.violence} />
              <Bar dataKey="terrorism" stackId="a" fill={CATEGORY_COLORS.terrorism} />
            </BarChart>
          </div>
          ) : (
            <div style={{ padding: '2rem', textAlign: 'center', backgroundColor: '#f8f9fa', borderRadius: '8px' }}>
              <p className="text-muted">No daily trend data available yet. Visit some pages to build analytics.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AnalyticsTab;