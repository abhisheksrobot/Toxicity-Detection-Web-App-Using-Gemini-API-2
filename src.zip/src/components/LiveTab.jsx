import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const LiveTab = ({ liveToxicityData }) => {
  const [liveData, setLiveData] = useState([]);
  const [toxicityBreakdown, setToxicityBreakdown] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const CATEGORY_LABELS = {
    toxic: 'Toxic',
    severe_toxic: 'Severe Toxic',
    obscene: 'Obscene',
    threat: 'Threat',
    insult: 'Insult',
    identity_hate: 'Identity Hate',
    sexuality: 'Explicit Content',
    violence: 'Violence',
    terrorism: 'Terrorism',
  };

  useEffect(() => {
    // Load historical data
    setIsLoading(true);
    chrome.storage.local.get('liveData', (result) => {
      if (result.liveData && Array.isArray(result.liveData)) {
        const nowTs = Date.now();
        const cutoff = nowTs - 24 * 60 * 60 * 1000;
        const filtered = result.liveData
          .filter(entry => entry?.time && entry.time > cutoff)
          .sort((a, b) => a.time - b.time);
        setLiveData(filtered);
      }
      setIsLoading(false);
    });
  }, []);

  useEffect(() => {
    if (liveToxicityData) {
      const now = new Date();
      const newEntry = { time: now.getTime(), toxicity: liveToxicityData.score };

      setLiveData(prevData => {
        const twentyFourHoursAgo = now.getTime() - 24 * 60 * 60 * 1000;
        const filteredData = prevData
          .filter(entry => entry.time > twentyFourHoursAgo)
          .sort((a, b) => a.time - b.time);
        // Prevent duplicate points if timestamp matches last entry (content script also logs to storage)
        if (filteredData.length && Math.abs(filteredData[filteredData.length - 1].time - newEntry.time) < 500) {
          return filteredData;
        }
        const updated = [...filteredData, newEntry];
        return updated.sort((a, b) => a.time - b.time);
      });

      if (liveToxicityData.breakdown) {
        const orderedKeys = ['toxic', 'severe_toxic', 'obscene', 'threat', 'insult', 'identity_hate', 'sexuality', 'violence', 'terrorism'];
        // Breakdown already comes as percentages (0-100) from content.js
        const breakdownData = orderedKeys.map((name) => ({ name, value: liveToxicityData.breakdown[name] || 0 }));
        setToxicityBreakdown(breakdownData);
      }
    }
  }, [liveToxicityData]);

  useEffect(() => {
    const interval = setInterval(() => {
      chrome.storage.local.set({ liveData });
    }, 60000);

    return () => {
      clearInterval(interval);
    };
  }, [liveData]);

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#d0ed57', '#a4de6c'];

  const now = new Date();
  const twentyFourHoursAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

  const timeTicks = [];
  for (let i = 0; i <= 12; i++) {
    timeTicks.push(new Date(twentyFourHoursAgo.getTime() + i * 2 * 60 * 60 * 1000).getTime());
  }

  const formatTick = (tick) => {
    const date = new Date(tick);
    if (tick === timeTicks[0] || tick === timeTicks[timeTicks.length - 1]) {
      return `${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} ${date.toLocaleDateString()}`;
    }
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (isLoading) {
    return (
      <div style={{ textAlign: 'center', padding: '2rem' }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
        <p className="mt-2">Loading chart data...</p>
      </div>
    );
  }

  return (
    <div>
      <h4>Real-time Toxicity (24h Trend)</h4>
      {liveData.length > 0 ? (
      <div style={{ width: '100%', display: 'flex', justifyContent: 'center', overflow: 'hidden', marginBottom: '1rem' }}>
        <div style={{ width: '350px', height: '200px' }}>
        <ResponsiveContainer width={350} height={200} minWidth={200} minHeight={150}>
          <LineChart data={liveData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis 
              dataKey="time" 
              type="number" 
              domain={[twentyFourHoursAgo.getTime(), now.getTime()]}
              ticks={timeTicks}
              tickFormatter={formatTick}
              tick={{ fill: '#111827', fontSize: 12 }}
            />
            <YAxis tick={{ fill: '#111827', fontSize: 12 }} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#ffffff', color: '#111827', border: '1px solid #e5e7eb' }}
              labelFormatter={(label) => {
                try {
                  return new Date(label).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                } catch {
                  return label;
                }
              }}
              formatter={(value) => [`${Number(value || 0).toFixed(0)}`, 'toxicity']}
            />
            <Legend wrapperStyle={{ color: '#111827' }} />
            <Line type="monotone" dataKey="toxicity" stroke="#8884d8" dot={false} />
          </LineChart>
        </ResponsiveContainer>
        </div>
      </div>
      ) : (
        <div style={{ padding: '2rem', textAlign: 'center', backgroundColor: '#f8f9fa', borderRadius: '8px' }}>
          <p className="text-muted">No data available yet. Visit some websites to see toxicity trends.</p>
        </div>
      )}

      <h4 className="mt-4">Toxicity Breakdown</h4>
      <div style={{ padding: '10px 0' }}>
        {toxicityBreakdown.map((item, index) => {
          const getColor = (name) => {
            const colorMap = {
              'toxic': '#dc3545',
              'severe_toxic': '#9163FF',
              'obscene': '#ff8042',
              'threat': '#fd7e14',
              'insult': '#ffc107',
              'identity_hate': '#6c757d',
              'sexuality': '#e83e8c',
              'violence': '#8b0000',
              'terrorism': '#000000'
            };
            return colorMap[name] || '#8884d8';
          };

          return (
            <div key={item.name} style={{ marginBottom: '12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                <span style={{ fontWeight: '500', textTransform: 'capitalize', color: '#111827' }}>
                  {CATEGORY_LABELS[item.name] || item.name.replace('_', ' ')}
                </span>
                <span style={{ fontWeight: '600', color: '#111827' }}>
                  {Number.isFinite(item.value) ? Math.round(item.value * 10) / 10 : 0}%
                </span>
              </div>
              <div style={{ 
                width: '100%', 
                height: '24px', 
                backgroundColor: '#e5e7eb', 
                borderRadius: '4px',
                overflow: 'hidden'
              }}>
                <div style={{ 
                  width: `${item.value}%`, 
                  height: '100%', 
                  backgroundColor: getColor(item.name),
                  transition: 'width 0.3s ease'
                }}></div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default LiveTab;