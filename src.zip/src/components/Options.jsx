import React from 'react';

const Options = () => {
  return (
    <div>
      <h1>Options Page</h1>
      <p>Configure your settings here.</p>
    </div>
  );
};

export default Options;