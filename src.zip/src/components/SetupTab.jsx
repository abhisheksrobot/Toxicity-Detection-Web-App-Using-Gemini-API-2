import React, { useState, useEffect } from 'react';
import { Lock, Settings, Bell, Shield, Palette, KeyRound } from 'lucide-react';
import { sendEmail } from '../emailService';

const SetupTab = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [activeSection, setActiveSection] = useState('api');
  const [masterPassword, setMasterPassword] = useState('Admin@1234');

  useEffect(() => {
    // Check if the user is already authenticated in this session
    if (sessionStorage.getItem('isAuthenticated')) {
      setIsAuthenticated(true);
    }
    // Load stored master password
    chrome.storage.local.get('masterPassword', (result) => {
      if (result.masterPassword) {
        setMasterPassword(result.masterPassword);
      }
    });
  }, []);

  const handleLogin = () => {
    if (password === masterPassword) {
      setIsAuthenticated(true);
      sessionStorage.setItem('isAuthenticated', 'true');
    } else {
      alert('Incorrect password');
    }
  };

  const renderSection = () => {
    switch (activeSection) {
      case 'api':
        return <GoogleApiSetup />;
      case 'notifications':
        return <EmailNotificationSetup />;
      case 'parental':
        return <ParentalControls />;
      case 'password':
        return <ChangePassword />;
      default:
        return <GoogleApiSetup />;
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="text-center">
        <Lock size={48} className="mb-3" />
        <h3>Enter Master Password</h3>
        <input
          type="password"
          className="form-control mb-3"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={{ color: 'white', backgroundColor: '#333' }}
        />
        <button className="btn btn-primary" onClick={handleLogin}>
          Unlock
        </button>
      </div>
    );
  }

  return (
    <div className="setup-tab">
      <div className="setup-nav-horizontal">
        <button onClick={() => setActiveSection('api')} className={`btn ${activeSection === 'api' ? 'btn-primary' : 'btn-light'}`}><Settings size={16} className="me-2" /> Google API</button>
        <button onClick={() => setActiveSection('notifications')} className={`btn ${activeSection === 'notifications' ? 'btn-primary' : 'btn-light'}`}><Bell size={16} className="me-2" /> Notifications</button>
        <button onClick={() => setActiveSection('parental')} className={`btn ${activeSection === 'parental' ? 'btn-primary' : 'btn-light'}`}><Shield size={16} className="me-2" /> Parental</button>
        <button onClick={() => setActiveSection('password')} className={`btn ${activeSection === 'password' ? 'btn-primary' : 'btn-light'}`}><KeyRound size={16} className="me-2" /> Password</button>
      </div>
      <div className="setup-content">
        {renderSection()}
      </div>
      <ToxicityReferenceScale />
    </div>
  );
};

const GoogleApiSetup = () => {
  const [apiKey, setApiKey] = useState('');
  const [selectedModel, setSelectedModel] = useState('gemini-2.5-flash');
  const [availableModels, setAvailableModels] = useState([]);
  const [loadingModels, setLoadingModels] = useState(false);

  useEffect(() => {
    chrome.storage.local.get(['geminiApiKey', 'geminiModel'], (result) => {
      if (result.geminiApiKey) {
        setApiKey(result.geminiApiKey);
      }
      if (result.geminiModel) {
        setSelectedModel(result.geminiModel);
      }
    });
  }, []);

  const fetchAvailableModels = async () => {
    if (!apiKey) {
      alert('Please enter an API key first');
      return;
    }
    
    setLoadingModels(true);
    try {
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`);
      if (!response.ok) {
        throw new Error('Failed to fetch models');
      }
      const data = await response.json();
      const models = data.models
        .filter(m => m.supportedGenerationMethods?.includes('generateContent'))
        .map(m => m.name.replace('models/', ''));
      setAvailableModels(models);
      if (models.length > 0 && !models.includes(selectedModel)) {
        setSelectedModel(models[0]);
      }
    } catch (error) {
      console.error('Error fetching models:', error);
      alert('Failed to fetch models. Check your API key.');
    } finally {
      setLoadingModels(false);
    }
  };

  const handleSave = () => {
    chrome.storage.local.set({ 
      geminiApiKey: apiKey,
      geminiModel: selectedModel 
    }, () => {
      alert('Settings saved!');
    });
  };

  return (
    <div>
      <h4>Google Gemini API Configuration</h4>
      <div className="mb-3">
        <label htmlFor="apiKey" className="form-label">API Key</label>
        <input
          type="text"
          className="form-control"
          id="apiKey"
          value={apiKey}
          onChange={(e) => setApiKey(e.target.value)}
          placeholder="Enter your Gemini API key"
        />
        <small className="form-text text-muted">
          Get your API key from <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer">Google AI Studio</a>
        </small>
      </div>
      
      <div className="mb-3">
        <label htmlFor="modelSelect" className="form-label">Model</label>
        <div className="input-group">
          <select
            className="form-select"
            id="modelSelect"
            value={selectedModel}
            onChange={(e) => setSelectedModel(e.target.value)}
            disabled={availableModels.length === 0}
          >
            {availableModels.length === 0 ? (
              <option value="gemini-2.5-flash">gemini-2.5-flash (default)</option>
            ) : (
              availableModels.map(model => (
                <option key={model} value={model}>{model}</option>
              ))
            )}
          </select>
          <button 
            className="btn btn-outline-secondary" 
            type="button"
            onClick={fetchAvailableModels}
            disabled={loadingModels || !apiKey}
          >
            {loadingModels ? 'Loading...' : 'Fetch Models'}
          </button>
        </div>
        <small className="form-text text-muted">
          Click "Fetch Models" to load available models for your API key
        </small>
      </div>
      
      <button className="btn btn-primary" onClick={handleSave}>Save Configuration</button>
    </div>
  );
};

const EmailNotificationSetup = () => {
  const [emailAlertsEnabled, setEmailAlertsEnabled] = useState(false);
  const [liveDetectionEnabled, setLiveDetectionEnabled] = useState(true);
  const [toEmail, setToEmail] = useState('');
  const [web3formsKey, setWeb3formsKey] = useState('');
  const [notifyOnParentalBlock, setNotifyOnParentalBlock] = useState(false);
  const [passwordModal, setPasswordModal] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [scanIntervalMinutes, setScanIntervalMinutes] = useState(30);
  const [categoryThresholds, setCategoryThresholds] = useState({
    toxic: 70,
    severe_toxic: 50,
    obscene: 60,
    threat: 80,
    insult: 70,
    identity_hate: 75,
    sexuality: 65,
    violence: 80,
    terrorism: 90
  });

  useEffect(() => {
    chrome.storage.local.get(['emailSettings', 'liveDetectionEnabled', 'scanIntervalMinutes'], (result) => {
      if (result.emailSettings) {
        setEmailAlertsEnabled(result.emailSettings.emailAlertsEnabled || false);
        setToEmail(result.emailSettings.toEmail || '');
        setWeb3formsKey(result.emailSettings.web3formsKey || '');
        setNotifyOnParentalBlock(result.emailSettings.notifyOnParentalBlock || false);
        setCategoryThresholds(result.emailSettings.categoryThresholds || {
          toxic: 70,
          severe_toxic: 50,
          obscene: 60,
          threat: 80,
          insult: 70,
          identity_hate: 75,
          sexuality: 65,
          violence: 80,
          terrorism: 90
        });
      }
      if (result.liveDetectionEnabled !== undefined) {
        setLiveDetectionEnabled(result.liveDetectionEnabled);
      }
      const interval = result.scanIntervalMinutes || result?.emailSettings?.scanIntervalMinutes;
      if (interval && !Number.isNaN(Number(interval))) {
        setScanIntervalMinutes(Number(interval));
      }
    });
  }, []);

  const handleLiveDetectionToggle = (newValue) => {
    if (!newValue) {
      // Toggling OFF - require password
      setPasswordModal(true);
      setPasswordInput('');
    } else {
      // Toggling ON - no password needed
      setLiveDetectionEnabled(true);
      chrome.storage.local.set({ liveDetectionEnabled: true });
    }
  };

  const handlePasswordConfirm = () => {
    if (passwordInput === 'Admin@1234') {
      setLiveDetectionEnabled(false);
      chrome.storage.local.set({ liveDetectionEnabled: false });
      setPasswordModal(false);
      setPasswordInput('');

      // Send email notification about live detection being disabled
      chrome.runtime.sendMessage({
        type: 'sendLiveDetectionDisabledEmail',
        data: {
          timestamp: new Date().toISOString(),
        }
      }).catch(() => {});

      alert('Live detection disabled. Email notification sent.');
    } else {
      alert('Incorrect password');
      setPasswordInput('');
    }
  };

  const handleSave = () => {
    chrome.storage.local.set({
      emailSettings: {
        emailAlertsEnabled,
        toEmail,
        web3formsKey,
        notifyOnParentalBlock,
        categoryThresholds,
        scanIntervalMinutes,
      },
      scanIntervalMinutes,
    }, () => {
      alert('Email settings saved!');
    });
  };

  const formatCategoryName = (category) => category === 'sexuality' ? 'Explicit Content' : category.replace(/_/g, ' ');

  const handleAnalyzeNow = () => {
    chrome.storage.local.get('analyzeNowTimestamps', (res) => {
      const now = Date.now();
      const windowAgo = now - 30 * 60 * 1000;
      const recent = (res.analyzeNowTimestamps || []).filter((ts) => ts > windowAgo);
      if (recent.length >= 2) {
        alert('You can run Analyze Now only 2 times every 30 minutes. Try again later.');
        return;
      }

      const updated = [...recent, now];
      chrome.storage.local.set({ analyzeNowTimestamps: updated }, () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const activeTab = tabs?.[0];
          if (!activeTab) return;
          try {
            chrome.tabs.sendMessage(activeTab.id, { type: 'forceAnalyze', bypassInterval: true });
            alert('Manual analysis triggered.');
          } catch (e) {
            console.error('Unable to trigger analysis', e);
            alert('Unable to trigger analysis on this page.');
          }
        });
      });
    });
  };

  const handleTestEmail = async () => {
    try {
      const result = await sendEmail({
        subject: 'Test Email from Toxicity Detector',
        message: 'This is a test email. If you receive this, your email configuration is working correctly!',
      });
      if (result.success) {
        alert('✅ Test email sent successfully! Check your inbox.');
      } else {
        alert('❌ Failed to send test email: ' + result.message);
      }
    } catch (err) {
      alert('❌ Error sending test email: ' + err.message);
    }
  };

  if (passwordModal) {
    return (
      <div className="alert alert-warning">
        <h5 className="mb-3">Confirm Master Password</h5>
        <p>Enter your master password to disable live detection:</p>
        <input
          type="password"
          className="form-control mb-3"
          value={passwordInput}
          onChange={(e) => setPasswordInput(e.target.value)}
          placeholder="Enter master password"
        />
        <div className="d-flex gap-2">
          <button className="btn btn-danger" onClick={handlePasswordConfirm}>Confirm</button>
          <button className="btn btn-secondary" onClick={() => {
            setPasswordModal(false);
            setPasswordInput('');
            setLiveDetectionEnabled(true);
          }}>Cancel</button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <h4>Email Notification Setup</h4>
      <div className="alert alert-info">
        <strong>Setup Instructions:</strong>
        <ol className="mb-0 mt-2">
          <li>Go to <a href="https://web3forms.com" target="_blank" rel="noopener noreferrer">web3forms.com</a></li>
          <li>Enter your email and get a free access key</li>
          <li>Paste the access key below</li>
          <li>Enable email alerts and test</li>
        </ol>
      </div>

      <div className="form-check form-switch mb-3">
        <input
          className="form-check-input"
          type="checkbox"
          role="switch"
          id="emailAlertsToggle"
          checked={emailAlertsEnabled}
          onChange={(e) => setEmailAlertsEnabled(e.target.checked)}
        />
        <label className="form-check-label" htmlFor="emailAlertsToggle">
          Enable Email Alerts
        </label>
      </div>

      <div className="form-check form-switch mb-3">
        <input
          className="form-check-input"
          type="checkbox"
          role="switch"
          id="notifyParentalToggle"
          checked={notifyOnParentalBlock}
          onChange={(e) => setNotifyOnParentalBlock(e.target.checked)}
        />
        <label className="form-check-label" htmlFor="notifyParentalToggle">
          Email me when content is blocked by Parental Controls
        </label>
      </div>

      <div className="mb-3">
        <label htmlFor="toEmail" className="form-label">Your Email Address</label>
        <input 
          type="email" 
          className="form-control" 
          id="toEmail" 
          value={toEmail} 
          onChange={(e) => setToEmail(e.target.value)}
          placeholder="your-email@example.com"
        />
        <small className="form-text text-muted">Alerts will be sent to this email</small>
      </div>

      <div className="mb-3">
        <label htmlFor="web3formsKey" className="form-label">Web3Forms Access Key</label>
        <input 
          type="text" 
          className="form-control" 
          id="web3formsKey" 
          value={web3formsKey} 
          onChange={(e) => setWeb3formsKey(e.target.value)}
          placeholder="Get free key from web3forms.com"
        />
        <small className="form-text text-muted">Free forever - no credit card required</small>
      </div>

      <div className="mb-4">
        <h6 className="mb-3">Notification Thresholds by Category (0-100%)</h6>
        <div style={{ maxHeight: '200px', overflowY: 'auto', borderRadius: '8px', padding: '10px', backgroundColor: '#f8f9fa' }}>
          {Object.entries(categoryThresholds).map(([category, threshold]) => (
            <div key={category} className="mb-2">
              <div className="d-flex justify-content-between align-items-center">
                <label htmlFor={`threshold-${category}`} className="form-label mb-0" style={{ textTransform: 'capitalize', fontSize: '0.9rem' }}>
                  {formatCategoryName(category)}
                </label>
                <input 
                  type="number" 
                  id={`threshold-${category}`}
                  className="form-control" 
                  style={{ width: '80px' }}
                  min="0"
                  max="100"
                  value={threshold}
                  onChange={(e) => setCategoryThresholds({ ...categoryThresholds, [category]: parseInt(e.target.value) || 0 })}
                />
                <span style={{ fontSize: '0.85rem', color: '#666' }}>%</span>
              </div>
            </div>
          ))}
        </div>
        <small className="form-text text-muted d-block mt-2">Email alerts triggered when score exceeds threshold</small>
      </div>

      <div className="mb-4">
        <label htmlFor="scanInterval" className="form-label">Scan Interval (minutes)</label>
        <input
          type="number"
          id="scanInterval"
          className="form-control"
          min="5"
          max="180"
          value={scanIntervalMinutes}
          onChange={(e) => setScanIntervalMinutes(Math.max(5, Number(e.target.value) || 30))}
        />
        <small className="form-text text-muted">Default is 30 minutes. Lower values scan more frequently but use more API quota.</small>
      </div>

      <hr className="my-4" />

      <div className="form-check form-switch mb-3">
        <input
          className="form-check-input"
          type="checkbox"
          role="switch"
          id="liveDetectionToggle"
          checked={liveDetectionEnabled}
          onChange={(e) => handleLiveDetectionToggle(e.target.checked)}
        />
        <label className="form-check-label" htmlFor="liveDetectionToggle">
          Enable Live Detection
        </label>
        <small className="d-block text-muted">Disabling requires master password confirmation</small>
      </div>

      <div className="d-flex gap-2">
        <button className="btn btn-primary" onClick={handleSave}>Save Settings</button>
        <button className="btn btn-outline-secondary" onClick={handleTestEmail}>Send Test Email</button>
        <button className="btn btn-outline-primary" onClick={handleAnalyzeNow}>Analyze Now (2 per 30m)</button>
      </div>
    </div>
  );
};

const ParentalControls = () => {
  const [blockContent, setBlockContent] = useState(false);
  const [ageRestriction, setAgeRestriction] = useState('No Restriction');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    chrome.storage.local.get('parentalControls', (result) => {
      if (result.parentalControls) {
        setBlockContent(!!result.parentalControls.blockContent);
        setAgeRestriction(result.parentalControls.ageRestriction || 'No Restriction');
      }
    });
  }, []);

  const evaluateActiveTab = async () => {
    const { geminiApiKey, geminiModel } = await new Promise((resolve) => {
      chrome.storage.local.get(['geminiApiKey', 'geminiModel'], resolve);
    });

    if (!geminiApiKey) {
      alert('Add a Gemini API key before using parental controls.');
      return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const currentTab = tabs?.[0];
      if (!currentTab?.url) return;

      try {
        const model = geminiModel || 'gemini-2.5-flash';
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${geminiApiKey}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: `Decide if a site URL is appropriate for children. Return JSON {"unsafe": boolean, "reason": string}. Mark unsafe if adult content, hate, violence, gambling, or age-inappropriate material. URL: ${currentTab.url}`,
                  },
                ],
              },
            ],
            generationConfig: {
              responseMimeType: 'application/json',
              responseSchema: {
                type: 'OBJECT',
                properties: {
                  unsafe: { type: 'BOOLEAN' },
                  reason: { type: 'STRING' },
                },
              },
            },
          }),
        });

        if (!response.ok) {
          throw new Error(`Gemini returned ${response.status}`);
        }

        const json = await response.json();
        const text = json?.candidates?.[0]?.content?.parts?.[0]?.text;
        let result = { unsafe: false, reason: 'No decision' };
        if (text) {
          try {
            result = JSON.parse(text);
          } catch (parseErr) {
            console.warn('Could not parse parental control response', parseErr);
          }
        }

        if (result.unsafe) {
          chrome.tabs.update(currentTab.id, { url: 'https://www.google.com' });
          alert('Content blocked: ' + (result.reason || 'unsafe'));
        }
      } catch (err) {
        console.error('Parental control evaluation failed', err);
      }
    });
  };

  const handleSave = () => {
    setIsSaving(true);
    chrome.storage.local.set({ parentalControls: { blockContent, ageRestriction } }, async () => {
      setIsSaving(false);
      alert('Parental controls saved.');
      if (blockContent) {
        evaluateActiveTab();
      }
    });
  };

  return (
    <div>
      <h4>Parental Controls</h4>
      <div className="form-check">
        <input
          className="form-check-input"
          type="checkbox"
          id="blockContent"
          checked={blockContent}
          onChange={(e) => setBlockContent(e.target.checked)}
        />
        <label className="form-check-label" htmlFor="blockContent">
          Block Inappropriate Content
        </label>
      </div>
      <div className="mt-3">
        <label htmlFor="ageRestriction" className="form-label">Age Restriction</label>
        <select
          className="form-select"
          id="ageRestriction"
          value={ageRestriction}
          onChange={(e) => setAgeRestriction(e.target.value)}
        >
          <option>No Restriction</option>
          <option>13+</option>
          <option>16+</option>
          <option>18+</option>
        </select>
      </div>
      <button className="btn btn-primary mt-3" onClick={handleSave} disabled={isSaving}>
        {isSaving ? 'Saving...' : 'Save Controls'}
      </button>
      
      <hr className="my-4" />
      
      <h5>Whitelist (Privacy Protection)</h5>
      <p className="text-muted small">
        Add trusted domains that should never be sent to Gemini API for checking.
        This protects your privacy on banking, work, and personal sites.
      </p>
      <WhitelistManager />
    </div>
  );
};

const WhitelistManager = () => {
  const [whitelist, setWhitelist] = useState([]);
  const [newDomain, setNewDomain] = useState('');

  useEffect(() => {
    chrome.storage.local.get('whitelist', (result) => {
      setWhitelist(result.whitelist || []);
    });
  }, []);

  const handleAdd = () => {
    if (!newDomain.trim()) return;
    
    const domain = newDomain.trim().toLowerCase();
    if (whitelist.includes(domain)) {
      alert('Domain already in whitelist');
      return;
    }

    const updated = [...whitelist, domain];
    setWhitelist(updated);
    chrome.storage.local.set({ whitelist: updated }, () => {
      setNewDomain('');
      console.log('Whitelist updated:', updated);
    });
  };

  const handleRemove = (domain) => {
    const updated = whitelist.filter(d => d !== domain);
    setWhitelist(updated);
    chrome.storage.local.set({ whitelist: updated });
  };

  return (
    <div>
      <div className="input-group mb-3">
        <input
          type="text"
          className="form-control"
          placeholder="example.com"
          value={newDomain}
          onChange={(e) => setNewDomain(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleAdd()}
        />
        <button className="btn btn-outline-primary" onClick={handleAdd}>
          Add Domain
        </button>
      </div>
      
      {whitelist.length > 0 && (
        <ul className="list-group">
          {whitelist.map((domain) => (
            <li key={domain} className="list-group-item d-flex justify-content-between align-items-center">
              {domain}
              <button 
                className="btn btn-sm btn-danger" 
                onClick={() => handleRemove(domain)}
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
      
      {whitelist.length === 0 && (
        <p className="text-muted small">No whitelisted domains yet.</p>
      )}
    </div>
  );
};

const ChangePassword = () => {
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [repeatPassword, setRepeatPassword] = useState('');
  const [storedPassword, setStoredPassword] = useState('Admin@1234');

  useEffect(() => {
    // Load current master password from storage
    chrome.storage.local.get('masterPassword', (result) => {
      if (result.masterPassword) {
        setStoredPassword(result.masterPassword);
      }
    });
  }, []);

  const handleChangePassword = () => {
    // Validate old password against stored password
    if (oldPassword !== storedPassword) {
      alert('❌ Old password is incorrect');
      return;
    }

    // Validate new password
    if (!newPassword || newPassword.length < 6) {
      alert('❌ New password must be at least 6 characters');
      return;
    }

    // Validate passwords match
    if (newPassword !== repeatPassword) {
      alert('❌ New passwords do not match');
      return;
    }

    // Password validation passed - store new password in chrome storage
    chrome.storage.local.set({ masterPassword: newPassword }, async () => {
      setStoredPassword(newPassword);
      
      // Send email notification about password change
      try {
        const result = await sendEmail({
          subject: '🔐 Master Password Changed',
          message: `Your Toxicity Detector master password has been changed.\n\nNew Password: ${newPassword}\n\nIf you did not make this change, please contact support immediately.`
        });
        if (result.success) {
          alert('✅ Master password changed successfully! Confirmation email sent.');
        } else {
          alert('✅ Master password changed successfully! (Note: Could not send email notification)');
        }
      } catch (err) {
        alert('✅ Master password changed successfully! (Note: Could not send email notification)');
        console.error('Error sending email:', err);
      }
      
      setOldPassword('');
      setNewPassword('');
      setRepeatPassword('');
    });
  };

  return (
    <div>
      <h4>Change Master Password</h4>
      <div className="alert alert-info" style={{ fontSize: '0.9rem' }}>
        <strong>Note:</strong> Enter your current password and set a new one (minimum 6 characters).
      </div>
      <div className="mb-3">
        <label htmlFor="oldPassword">Old Password</label>
        <input
          type="password"
          className="form-control"
          id="oldPassword"
          value={oldPassword}
          onChange={(e) => setOldPassword(e.target.value)}
          placeholder="Enter current master password"
        />
      </div>
      <div className="mb-3">
        <label htmlFor="newPassword">New Password</label>
        <input
          type="password"
          className="form-control"
          id="newPassword"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          placeholder="Enter new password (min 6 characters)"
        />
      </div>
      <div className="mb-3">
        <label htmlFor="repeatPassword">Repeat New Password</label>
        <input
          type="password"
          className="form-control"
          id="repeatPassword"
          value={repeatPassword}
          onChange={(e) => setRepeatPassword(e.target.value)}
          placeholder="Confirm new password"
        />
      </div>
      <button className="btn btn-primary" onClick={handleChangePassword}>
        Change Password
      </button>
    </div>
  );
};

const ToxicityReferenceScale = () => (
  <div className="mt-4">
    <h4>Toxicity Reference Scale</h4>
    <div className="d-flex flex-column gap-2">
      <div className="p-2 bg-success text-white rounded">0-10% Suitable</div>
      <div className="p-2 bg-info text-white rounded">11-25% Okay</div>
      <div className="p-2 bg-primary text-white rounded">26-35% Average</div>
      <div className="p-2 bg-warning text-dark rounded">36-50% Medium</div>
      <div className="p-2 bg-danger text-white rounded">51-70% High</div>
      <div className="p-2" style={{ backgroundColor: '#DC3545', color: 'white', borderRadius: '0.25rem' }}>71-85% Worse</div>
      <div className="p-2" style={{ backgroundColor: '#9163FF', color: 'white', borderRadius: '0.25rem' }}>86-100% Extreme</div>
    </div>
  </div>
);

export default SetupTab;