import React, { useState, useEffect } from 'react';

const CompareTab = () => {
  const [domains, setDomains] = useState([]);

  useEffect(() => {
    chrome.storage.local.get('recentDomains', (result) => {
      if (result.recentDomains) {
        const domainList = Object.values(result.recentDomains || {});
        domainList.sort((a, b) => {
          const aTime = new Date(a.last_visited || a.timestamp || 0).getTime();
          const bTime = new Date(b.last_visited || b.timestamp || 0).getTime();
          return bTime - aTime;
        });
        setDomains(domainList.slice(0, 20));
      }
    });
  }, []);

  const getColor = (toxicity) => {
    if (toxicity <= 10) return '#198754';
    if (toxicity <= 25) return '#9AD91E';
    if (toxicity <= 35) return '#0D6EFD';
    if (toxicity <= 50) return '#FFC107';
    if (toxicity <= 70) return '#FD7E14';
    if (toxicity <= 85) return '#DC3545';
    return '#9163FF';
  };

  const averageToxicity = domains.length > 0 ? Math.round(domains.reduce((acc, domain) => acc + domain.toxicity_score, 0) / domains.length) : 0;

  const formatTime = (timestamp) => {
    if (!timestamp) return 'Unknown time';
    try {
      const date = new Date(timestamp);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return 'Unknown time';
    }
  };

  return (
    <div>
      <div className="card mb-4">
        <div className="card-body">
          <h5 className="card-title">Website Toxicity Comparison</h5>
          <ul className="list-group">
            {domains.map((domain) => (
              <li key={domain.host} className="list-group-item">
                <div className="d-flex justify-content-between">
                  <span>
                    {domain.host}
                    <span className="text-muted ms-2" style={{ fontSize: '0.85rem' }}>
                      {formatTime(domain.last_visited || domain.timestamp)}
                    </span>
                  </span>
                  <span>{domain.classification}</span>
                </div>
                <div className="progress">
                  <div
                    className="progress-bar"
                    role="progressbar"
                    style={{ width: `${domain.toxicity_score}%`, backgroundColor: getColor(domain.toxicity_score) }}
                    aria-valuenow={domain.toxicity_score}
                    aria-valuemin="0"
                    aria-valuemax="100"
                  >
                    {domain.toxicity_score}%
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="row">
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Sites Analyzed</h5>
              <p>{domains.length}</p>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Average Toxicity</h5>
              <p>{averageToxicity}%</p>
            </div>
          </div>
        </div>
      </div>
      <div className="card mt-4">
        <div className="card-body">
          <h5 className="card-title">Download History</h5>
          <button 
            className="btn btn-primary"
            onClick={() => {
              chrome.storage.local.get('history', (result) => {
                if (result.history && result.history.length > 0) {
                  const csvContent = [
                    'Domain,Toxicity Score,Classification,Timestamp,Toxic,Severe Toxic,Obscene,Threat,Insult,Identity Hate,Explicit Content,Violence,Terrorism',
                    ...result.history.map(item => 
                      `"${item.host}",${item.toxicity_score},"${item.classification}","${item.timestamp}",${item.attributes?.toxic || 0},${item.attributes?.severe_toxic || 0},${item.attributes?.obscene || 0},${item.attributes?.threat || 0},${item.attributes?.insult || 0},${item.attributes?.identity_hate || 0},${item.attributes?.sexuality || 0},${item.attributes?.violence || 0},${item.attributes?.terrorism || 0}`
                    )
                  ].join('\n');
                  
                  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                  const link = document.createElement('a');
                  const url = URL.createObjectURL(blob);
                  link.setAttribute('href', url);
                  link.setAttribute('download', `toxicity-history-${new Date().toISOString().split('T')[0]}.csv`);
                  link.style.visibility = 'hidden';
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                } else {
                  alert('No history to download');
                }
              });
            }}
          >
            Download All History
          </button>
        </div>
      </div>
    </div>
  );
};

export default CompareTab;