import React, { useState, useEffect } from 'react';
import { Eye, Activity, Settings } from 'lucide-react';
import LiveTab from './components/LiveTab';
import AnalyticsTab from './components/AnalyticsTab';
import CompareTab from './components/CompareTab';
import SetupTab from './components/SetupTab';
import { sendEmail } from './emailService';
import { connectToDb } from './db';

const App = () => {
  const [activeTab, setActiveTab] = useState('live');
  const [isLive, setIsLive] = useState(true);
  const [currentToxicity, setCurrentToxicity] = useState({ score: 0, classification: 'Suitable', breakdown: { toxic: 0, severe_toxic: 0, obscene: 0, threat: 0, insult: 0, identity_hate: 0, sexuality: 0, violence: 0, terrorism: 0 } });
  const [currentDomain, setCurrentDomain] = useState('');
  const [lastUpdated, setLastUpdated] = useState('');
  const [parentalControls, setParentalControls] = useState({
    blockInappropriateContent: false,
    ageRestriction: 'No Restriction',
  });
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    const messageListener = (message, sender, sendResponse) => {
      console.log('Popup received message:', message);
      if (message.type === 'toxicityScore') {
        const score = message.data.overallScore;
        console.log('Setting toxicity score in popup:', score);
        let classification = 'Suitable';
        if (score > 70) classification = 'Extreme';
        else if (score > 50) classification = 'High';
        else if (score > 35) classification = 'Medium';
        else if (score > 25) classification = 'Average';
        else if (score > 10) classification = 'Okay';
        const initialBreakdown = { toxic: 0, severe_toxic: 0, obscene: 0, threat: 0, insult: 0, identity_hate: 0, sexuality: 0, violence: 0, terrorism: 0 };
        const breakdown = message.data.breakdown ? { ...initialBreakdown, ...message.data.breakdown } : initialBreakdown;
        setCurrentToxicity({ score, classification, breakdown });
        setErrorMessage('');
        try {
          setLastUpdated(new Date().toLocaleTimeString());
        } catch {}
      } else if (message.type === 'toxicityError') {
        setErrorMessage(message?.data?.message || 'Analysis failed');
      }
    };
    chrome.runtime.onMessage.addListener(messageListener);
    return () => chrome.runtime.onMessage.removeListener(messageListener);
  }, []);

  useEffect(() => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].url) {
        try {
          const hostname = new URL(tabs[0].url).hostname;
          setCurrentDomain(hostname);
          
          // Load cached data for this domain immediately to avoid triggering new analysis
          chrome.storage.local.get(['history', 'liveData'], (res) => {
            // Try to find the most recent entry for current domain
            const history = res.history || [];
            const recentEntry = history.find(entry => entry.host === hostname);
            
            if (recentEntry && recentEntry.attributes) {
              const score = recentEntry.toxicity_score || 0;
              let classification = 'Suitable';
              if (score > 70) classification = 'Extreme';
              else if (score > 50) classification = 'High';
              else if (score > 35) classification = 'Medium';
              else if (score > 25) classification = 'Average';
              else if (score > 10) classification = 'Okay';
              setCurrentToxicity({ score, classification, breakdown: recentEntry.attributes });
            } else {
              // Fallback to last liveData point
              const arr = res.liveData;
              if (Array.isArray(arr) && arr.length > 0) {
                const last = arr[arr.length - 1];
                const score = last.toxicity || 0;
                let classification = 'Suitable';
                if (score > 70) classification = 'Extreme';
                else if (score > 50) classification = 'High';
                else if (score > 35) classification = 'Medium';
                else if (score > 25) classification = 'Average';
                else if (score > 10) classification = 'Okay';
                const initialBreakdown = { toxic: 0, severe_toxic: 0, obscene: 0, threat: 0, insult: 0, identity_hate: 0, sexuality: 0, violence: 0, terrorism: 0 };
                setCurrentToxicity({ score, classification, breakdown: initialBreakdown });
              }
            }
          });
        } catch (e) {
          setCurrentDomain('');
        }
      }
    });
  }, []);

  useEffect(() => {
    const saveSettings = async () => {
      const db = connectToDb();
      await db.collection('settings').updateOne({}, { $set: { isLive } }, { upsert: true });
    };
    saveSettings();
  }, [isLive]);

  useEffect(() => {
    if (parentalControls.blockInappropriateContent) {
      // This is a simplified example. A real implementation would involve
      // a more sophisticated content analysis.
      const isToxic = document.title.toLowerCase().includes('toxic');
      if (isToxic) {
        window.location.href = 'https://www.google.com';
      }
    }
  }, [parentalControls.blockInappropriateContent]);

  const handleToggleClick = () => {
    const newIsLive = !isLive;
    setIsLive(newIsLive);
    sendEmail({
      subject: 'Live Detection Toggled',
      message: `Live detection has been ${newIsLive ? 'enabled' : 'disabled'}.`,
    });
  };

  const handleSetupClick = () => {
    setActiveTab('setup');
  };

  const renderTab = () => {
    switch (activeTab) {
      case 'live':
        return <LiveTab liveToxicityData={currentToxicity} />;
      case 'analytics':
        return <AnalyticsTab />;
      case 'compare':
        return <CompareTab />;
      case 'setup':
        return <SetupTab />;
      default:
        return <LiveTab liveToxicityData={currentToxicity} />;
    }
  };

  return (
    <div className="popup">
      <header className="header" style={{ background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)' }}>
        <div className="header-content">
          <div className="header-top">
            <div className="d-flex align-items-center">
              <Eye className="me-2" size={20} />
              <div>
                <h5 className="mb-0 text-white" style={{ fontSize: '1rem', fontWeight: '600' }}>Toxicity Detector</h5>
                <p className="mb-0 text-white" style={{ fontSize: '0.75rem', opacity: 0.9, lineHeight: '1.3' }}>
                  Live Analysis Tool {currentDomain ? `• ${currentDomain}` : ''} {lastUpdated ? `• Updated ${lastUpdated}` : ''}
                </p>
              </div>
            </div>
          </div>
          <div className="header-bottom">
            <div className="d-flex align-items-center gap-2 flex-wrap">
              <span className="badge bg-light text-dark" style={{ fontSize: '0.85rem', padding: '0.4rem 0.7rem' }}>
                {currentToxicity.score}% {currentToxicity.classification}
              </span>
              {typeof currentToxicity?.breakdown?.sexuality === 'number' && (
                <span className="badge" style={{ backgroundColor: '#8e44ad', fontSize: '0.85rem', padding: '0.4rem 0.7rem' }}>
                  Explicit Content {currentToxicity.breakdown.sexuality}%
                </span>
              )}
            </div>
          </div>
        </div>
      </header>
      {errorMessage && (
        <div className="alert alert-warning mb-0" style={{ borderRadius: 0 }}>
          {errorMessage}
        </div>
      )}
      {isLive && (
        <div className="live-banner">
          <Activity size={16} className="me-2" />
          Live Detection Active
        </div>
      )}
      <nav className="nav nav-tabs p-2">
        <button className={`nav-link ${activeTab === 'live' ? 'active' : ''}`} onClick={() => setActiveTab('live')}>
          Live
        </button>
        <button className={`nav-link ${activeTab === 'analytics' ? 'active' : ''}`} onClick={() => setActiveTab('analytics')}>
          Analytics
        </button>
        <button className={`nav-link ${activeTab === 'compare' ? 'active' : ''}`} onClick={() => setActiveTab('compare')}>
          Compare
        </button>
        <button className={`nav-link ${activeTab === 'setup' ? 'active' : ''}`} onClick={handleSetupClick}>
          <Settings size={16} />
        </button>
      </nav>
      <main className="content-area p-3">
        {renderTab()}
      </main>
    </div>
  );
};

export default App;