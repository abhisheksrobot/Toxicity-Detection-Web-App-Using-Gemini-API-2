// src/db.js

const getCollection = (name) => {
  const getAll = () => {
    return new Promise((resolve) => {
      chrome.storage.local.get(name, (result) => {
        resolve(result[name] || []);
      });
    });
  };

  const setAll = (data) => {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [name]: data }, () => {
        resolve();
      });
    });
  };

  return {
    async findOne(query) {
      const data = await getAll();
      return data.find(item => {
        return Object.keys(query).every(key => {
          if (key === '$set') return true; // Ignore $set for query purposes
          return item[key] === query[key];
        });
      });
    },
    async updateOne(query, update, options) {
      let data = await getAll();
      const itemIndex = data.findIndex(item => {
        return Object.keys(query).every(key => {
          return item[key] === query[key];
        });
      });

      if (itemIndex > -1) {
        // Update existing item
        data[itemIndex] = { ...data[itemIndex], ...update.$set };
      } else if (options.upsert) {
        // Insert new item
        data.push(update.$set);
      }
      await setAll(data);
    },
    async insertOne(doc) {
      const data = await getAll();
      data.push(doc);
      await setAll(data);
    }
  };
};

export const connectToDb = () => {
  return {
    collection: (name) => getCollection(name),
  };
};
