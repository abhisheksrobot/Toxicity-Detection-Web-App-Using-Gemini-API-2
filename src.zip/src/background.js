// src/background.js
import { DUMMY_HISTORY, DUMMY_RECENT_DOMAINS } from './dummy-data.js';

console.log("Background script loaded.");

const getFromStorage = (keys) => new Promise((resolve) => chrome.storage.local.get(keys, resolve));

const sendHistoryEmailWithCsv = async (reason = 'uninstall') => {
  try {
    const { emailSettings = {}, history = [] } = await getFromStorage(['emailSettings', 'history']);
    if (!emailSettings.emailAlertsEnabled || !emailSettings.toEmail) return;

    const csvLines = [
      'Domain,Toxicity Score,Classification,Timestamp,Toxic,Severe Toxic,Obscene,Threat,Insult,Identity Hate,Sexuality,Violence,Terrorism',
      ...history.map((item) => (
        `"${item.host}",${item.toxicity_score},"${item.classification}","${item.timestamp}",${item.attributes?.toxic || 0},${item.attributes?.severe_toxic || 0},${item.attributes?.obscene || 0},${item.attributes?.threat || 0},${item.attributes?.insult || 0},${item.attributes?.identity_hate || 0},${item.attributes?.sexuality || 0},${item.attributes?.violence || 0},${item.attributes?.terrorism || 0}`
      )),
    ].join('\n');

    // Keep email body reasonable length but still include CSV
    const maxCsvLength = 15000;
    const csvTrimmed = csvLines.length > maxCsvLength ? `${csvLines.slice(0, maxCsvLength)}... (truncated)` : csvLines;

    await fetch('https://api.web3forms.com/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        access_key: emailSettings.web3formsKey || '404899bc-17fb-43fe-bdfe-5ed7fa24ab65',
        email: emailSettings.toEmail,
        name: 'Toxicity Detector',
        subject: `📦 Backup on ${reason}`,
        message: `A backup was triggered (${reason}).\nEntries: ${history.length}\n\nCSV Preview:\n${csvTrimmed}`,
        history_csv: csvLines,
      }),
    });
  } catch (err) {
    console.error('Failed to send history backup email:', err);
  }
};

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    // Pre-populate storage with dummy data on first install
    const liveData = DUMMY_HISTORY.map(item => ({
      time: new Date(item.timestamp).getTime(),
      toxicity: item.toxicity_score,
    }));
    chrome.storage.local.set({
      liveData,
      history: DUMMY_HISTORY,
      recentDomains: DUMMY_RECENT_DOMAINS,
    });
  }
});

// Also seed on startup if storage is empty
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(['liveData','history','recentDomains'], (result) => {
    const needsSeed = !result.history || !Array.isArray(result.history) || result.history.length === 0;
    if (needsSeed) {
      const liveData = DUMMY_HISTORY.map(item => ({
        time: new Date(item.timestamp).getTime(),
        toxicity: item.toxicity_score,
      }));
      chrome.storage.local.set({
        liveData,
        history: DUMMY_HISTORY,
        recentDomains: DUMMY_RECENT_DOMAINS,
      });
    }
  });
});

// Optional: auto-block pages when parental controls enabled
// Cache to prevent duplicate checks within the same session
const checkedUrls = new Map();

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab?.url) return;

  // Skip internal pages
  if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://') || tab.url.startsWith('about:')) {
    return;
  }

  chrome.storage.local.get(['parentalControls', 'geminiApiKey', 'geminiModel', 'whitelist'], async (cfg) => {
    if (!cfg?.parentalControls?.blockContent || !cfg?.geminiApiKey) return;

    const host = (() => { 
      try { 
        return new URL(tab.url).hostname; 
      } catch { 
        return null; 
      }
    })();

    if (!host) return;

    // Check whitelist first (privacy feature)
    const whitelist = cfg.whitelist || [];
    if (whitelist.some(domain => host.includes(domain))) {
      console.log(`Skipping whitelisted domain: ${host}`);
      return;
    }

    // Check cache to avoid duplicate API calls
    const cacheKey = `${host}:${tab.url}`;
    if (checkedUrls.has(cacheKey)) {
      const cachedResult = checkedUrls.get(cacheKey);
      if (cachedResult.unsafe && Date.now() - cachedResult.timestamp < 3600000) { // 1 hour cache
        chrome.tabs.update(tabId, { url: 'https://www.google.com' });
      }
      return;
    }

    try {
      console.log(`Checking URL safety: ${tab.url}`);
      
      const model = cfg.geminiModel || 'gemini-2.5-flash';
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${cfg.geminiApiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: `Return JSON only as {"unsafe": boolean, "reason": string}. unsafe MUST be true for adult/pornographic/sexually explicit content, gambling, hate, or graphic violence. URL: ${tab.url}`,
            }],
          }],
          generationConfig: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: 'OBJECT',
              properties: { 
                unsafe: { type: 'BOOLEAN' }, 
                reason: { type: 'STRING' } 
              },
            },
            temperature: 0,
            topP: 0.1,
          },
        }),
      });

      if (!response.ok) {
        console.error(`Gemini API error: ${response.status}`);
        return;
      }

      const data = await response.json();
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
      let result = { unsafe: false, reason: '' };
      
      try { 
        if (text) result = JSON.parse(text); 
      } catch (e) {
        console.error('Failed to parse Gemini response:', e);
      }

      // Cache the result
      checkedUrls.set(cacheKey, { 
        unsafe: result.unsafe, 
        timestamp: Date.now() 
      });

      // Limit cache size to prevent memory issues
      if (checkedUrls.size > 1000) {
        const firstKey = checkedUrls.keys().next().value;
        checkedUrls.delete(firstKey);
      }

      if (result.unsafe) {
        console.log(`Blocking unsafe URL: ${tab.url} - Reason: ${result.reason}`);
        
        // Use Promise-based storage to avoid race conditions
        const storage = await chrome.storage.local.get(['history', 'recentDomains']);
        const now = new Date().toISOString();
        
        const entry = {
          toxicity_score: 100,
          classification: 'Blocked',
          host,
          timestamp: now,
          attributes: { sexuality: 100 },
          rationale: result.reason || 'Unsafe content detected',
        };

        const newHistory = Array.isArray(storage.history) ? [...storage.history, entry] : [entry];
        const recent = { ...(storage.recentDomains || {}) };
        recent[host] = entry;

        await chrome.storage.local.set({ 
          history: newHistory, 
          recentDomains: recent 
        });
        
        // Send email notification for parental block
        chrome.runtime.sendMessage({
          type: 'sendParentalBlockEmail',
          data: {
            url: tab.url,
            reason: result.reason || 'Unsafe content detected'
          }
        }).catch(() => {});

        // Block the page
        chrome.tabs.update(tabId, { url: 'https://www.google.com' });
      }
    } catch (error) {
      console.error('Error checking URL safety:', error);
    }
  });
});

chrome.runtime.setUninstallURL('https://your-website.com/uninstall');

if (chrome.runtime.onSuspend) {
  chrome.runtime.onSuspend.addListener(() => {
    sendHistoryEmailWithCsv('uninstall');
  });
}
// Handle email notifications from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'sendEmailNotification') {
    const { domain, overallScore, classification, triggeredCategories } = message.data;
    
    chrome.storage.local.get('emailSettings', async (result) => {
      const emailSettings = result.emailSettings || {};
      if (emailSettings.emailAlertsEnabled && emailSettings.toEmail) {
        try {
          const response = await fetch('https://api.web3forms.com/submit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              access_key: emailSettings.web3formsKey || '404899bc-17fb-43fe-bdfe-5ed7fa24ab65',
              email: emailSettings.toEmail,
              name: 'Toxicity Detector',
              subject: `⚠️ Toxicity Alert: ${domain}`,
              message: `Domain: ${domain}\nOverall Score: ${overallScore}%\nClassification: ${classification}\n\nTriggered Categories:\n${triggeredCategories.join('\n')}`
            })
          });
          console.log('Email sent for domain:', domain, 'Status:', response.status);
        } catch (err) {
          console.error('Error sending email notification:', err);
        }
      }
    });
  }
  
  if (message.type === 'sendParentalBlockEmail') {
    const { url, reason } = message.data;
    
    chrome.storage.local.get('emailSettings', async (result) => {
      const emailSettings = result.emailSettings || {};
      if (emailSettings.emailAlertsEnabled && emailSettings.notifyOnParentalBlock && emailSettings.toEmail) {
        try {
          const response = await fetch('https://api.web3forms.com/submit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              access_key: emailSettings.web3formsKey || '404899bc-17fb-43fe-bdfe-5ed7fa24ab65',
              email: emailSettings.toEmail,
              name: 'Toxicity Detector',
              subject: `🛡️ Content Blocked by Parental Controls`,
              message: `A webpage was blocked by your parental control settings.\n\nURL: ${url}\nReason: ${reason}`
            })
          });
          console.log('Parental block notification sent. Status:', response.status);
        } catch (err) {
          console.error('Error sending parental block notification:', err);
        }
      }
    });
  }

  if (message.type === 'sendLiveDetectionDisabledEmail') {
    chrome.storage.local.get('emailSettings', async (result) => {
      const emailSettings = result.emailSettings || {};
      if (emailSettings.emailAlertsEnabled && emailSettings.toEmail) {
        try {
          const response = await fetch('https://api.web3forms.com/submit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              access_key: emailSettings.web3formsKey || '404899bc-17fb-43fe-bdfe-5ed7fa24ab65',
              email: emailSettings.toEmail,
              name: 'Toxicity Detector',
              subject: `🔴 Live Detection Disabled`,
              message: `Live detection has been disabled on your Toxicity Detector.\n\nTimestamp: ${message.data.timestamp}\n\nTo re-enable, go to the Notifications tab in Settings.`
            })
          });
          console.log('Live detection disabled notification sent. Status:', response.status);
        } catch (err) {
          console.error('Error sending live detection disabled notification:', err);
        }
      }
    });
  }
});