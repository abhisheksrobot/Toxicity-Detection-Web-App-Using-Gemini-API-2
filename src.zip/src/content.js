// src/content.js
console.log('Content script loaded.');

// Visual indicator that content script is running (for debugging)
const indicator = document.createElement('div');
indicator.style.position = 'fixed';
indicator.style.bottom = '10px';
indicator.style.left = '10px';
indicator.style.padding = '5px 10px';
indicator.style.background = 'rgba(0, 0, 0, 0.7)';
indicator.style.color = 'white';
indicator.style.zIndex = '999999';
indicator.style.borderRadius = '5px';
indicator.style.fontSize = '12px';
indicator.style.pointerEvents = 'none';
indicator.textContent = 'Toxicity Detector: Active';
document.body.appendChild(indicator);

setTimeout(() => {
  indicator.remove();
}, 5000);

const calculateOverallToxicity = (breakdown) => {
  const weights = {
    toxic: 0.8,
    severe_toxic: 1.0,
    obscene: 0.9,
    threat: 1.0,
    insult: 0.7,
    identity_hate: 0.9,
    sexuality: 0.85,
    violence: 0.95,
    terrorism: 1.0,
  };

  let maxScore = 0;
  for (const key in breakdown) {
    if (weights[key]) {
      maxScore = Math.max(maxScore, breakdown[key] * weights[key]);
    }
  }
  return Math.round(maxScore * 100);
};

const extractModelJson = (json) => {
  const candidates = json?.candidates || [];
  for (const c of candidates) {
    const parts = c?.content?.parts || [];
    for (const p of parts) {
      if (typeof p?.text === 'string' && p.text.trim().length) return p.text;
      if (p?.functionCall?.args) return JSON.stringify(p.functionCall.args);
      if (p?.jsonValue) return JSON.stringify(p.jsonValue);
      if (p?.structValue) return JSON.stringify(p.structValue);
      if (p?.data) return JSON.stringify(p.data);
    }
  }
  return null;
};

// Page scanning cache to prevent duplicate scans
const pageCache = {
  currentUrl: window.location.href,
  currentText: '',
  lastScore: null,
  lastBreakdown: {},
  lastScanTime: 0,
};

const DEFAULT_SCAN_INTERVAL = 30 * 60 * 1000; // 30 minutes default
let scanIntervalMs = DEFAULT_SCAN_INTERVAL;
let quotaRetryUntil = 0;

const getConfiguredScanInterval = async () => {
  return new Promise((resolve) => {
    chrome.storage.local.get(['emailSettings', 'scanIntervalMinutes'], (result) => {
      const minutes = result.scanIntervalMinutes || result?.emailSettings?.scanIntervalMinutes;
      if (minutes && !Number.isNaN(Number(minutes))) {
        resolve(Number(minutes) * 60 * 1000);
      } else {
        resolve(DEFAULT_SCAN_INTERVAL);
      }
    });
  });
};

const getToxicityScore = async (text) => {
  const { geminiApiKey, geminiModel } = await new Promise((resolve) => {
    chrome.storage.local.get(['geminiApiKey', 'geminiModel'], resolve);
  });

  if (!geminiApiKey) {
    console.error('Gemini API key not found.');
    return { overallScore: 0, breakdown: {} };
  }

  const model = geminiModel || 'gemini-2.5-flash';
  const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${geminiApiKey}`;

  const defaultBreakdown = {
    toxic: 0,
    severe_toxic: 0,
    obscene: 0,
    threat: 0,
    insult: 0,
    identity_hate: 0,
    sexuality: 0,
    violence: 0,
    terrorism: 0,
  };

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: `Analyze the NATURE of the following text. You MUST return a valid JSON object with ALL 9 keys: ["toxic","severe_toxic","obscene","threat","insult","identity_hate","sexuality","violence","terrorism"]. IMPORTANT RULES: 1. Return a single JSON object only, no extra text before or after. 2. The JSON must have exactly these 9 keys. 3. Each value must be a decimal number between 0.0 and 1.0 with at most 2 decimal places (e.g., 0.85, 0.12, 0.00) where as per below scale:
                0.00-0.10 = Suitable
                0.11-0.25 = Okay
                0.26-0.35 = Average
                0.36-0.50 = Medium
                0.51-0.70 = High 
                0.71-0.85 = Worse 
                0.86-1.00 = Extreme 
                4. If a category is not present in the text, use 0.00 for that category. Category definitions: 1. toxic: general toxicity, rudeness, disrespectful language. 2. severe_toxic: extremely toxic, hateful, aggressive language. 3. obscene: profanity, vulgar language, swear words. 4. threat: threatening language, intimidation, warnings of harm. 5. insult: personal attacks, name-calling, derogatory remarks. 6. identity_hate: hate speech based on identity (race, religion, gender, etc.). 7. sexuality: sexually explicit or pornographic content, sex/porn keywords, adult language, nude/adult imagery descriptions. 8. violence: graphic violence, gore, brutal descriptions, weapon usage. 9. terrorism: terrorist or extremist content, radicalization, or violent ideologies.  
                Text: ${text.substring(0, 6000)}`,
              },
            ],
          },
        ],
        generationConfig: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: 'OBJECT',
            properties: {
              toxic: { type: 'NUMBER' },
              severe_toxic: { type: 'NUMBER' },
              obscene: { type: 'NUMBER' },
              threat: { type: 'NUMBER' },
              insult: { type: 'NUMBER' },
              identity_hate: { type: 'NUMBER' },
              sexuality: { type: 'NUMBER' },
              violence: { type: 'NUMBER' },
              terrorism: { type: 'NUMBER' },
            },
            required: ['toxic', 'severe_toxic', 'obscene', 'threat', 'insult', 'identity_hate', 'sexuality', 'violence', 'terrorism'],
          },
          temperature: 0,
          topP: 0.1,
        },
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Gemini API Error Body:', errorText);
      if (response.status === 429) {
        quotaRetryUntil = Date.now() + 30 * 60 * 1000; // back off 30 minutes
      }
      throw new Error(`API request failed with status ${response.status}`);
    }

    const json = await response.json();
    console.log('Gemini Raw Response:', JSON.stringify(json, null, 2));
    
    const modelText = extractModelJson(json);
    console.log('Extracted Model Text:', modelText);

    let breakdown = defaultBreakdown;

    if (modelText) {
      try {
        // Clean up malformed numbers (e.g., extremely long decimals or scientific notation with huge exponents)
        let cleanedText = modelText.replace(/:\s*0\.\d{10,}e-\d+/g, ': 0.0');
        cleanedText = cleanedText.replace(/:\s*0\.\d{100,}/g, ': 0.0');
        
        const parsed = JSON.parse(cleanedText);
        breakdown = { ...defaultBreakdown, ...parsed };
        console.log('Breakdown after merge:', breakdown);
      } catch (parseErr) {
        console.warn('Could not parse model response, using defaults.', parseErr);
      }
    }

    const normalizeToPercent = (raw) => {
      const num = Number(raw);
      if (Number.isNaN(num)) return 0;
      const percent = num <= 1 ? num * 100 : num;
      return Math.max(0, Math.min(100, Math.round(percent)));
    };

    const breakdownPercentages = {};
    for (const key of Object.keys(defaultBreakdown)) {
      const value = breakdown[key] !== undefined ? breakdown[key] : defaultBreakdown[key];
      breakdownPercentages[key] = normalizeToPercent(value);
    }

    console.log('Final breakdown percentages:', breakdownPercentages);
    const overallScore = calculateOverallToxicity(breakdown);
    return { overallScore, breakdown: breakdownPercentages };
  } catch (error) {
    console.error('Error analyzing toxicity:', error);
    try {
      chrome.runtime.sendMessage({ type: 'toxicityError', data: { message: error?.message || 'Analysis failed' } }).catch(() => {});
    } catch (e) {}
    return { overallScore: pageCache.lastScore || 0, breakdown: pageCache.lastBreakdown || {} };
  }
};

const hasPageChanged = (currentText) => {
  if (!pageCache.currentText) return true;
  const oldLength = pageCache.currentText.length;
  const newLength = currentText.length;
  const diff = Math.abs(oldLength - newLength);
  const percentChange = (diff / oldLength) * 100;
  return percentChange > 10;
};

const shouldScanPage = (currentText, intervalMs) => {
  const now = Date.now();
  if (now < quotaRetryUntil) {
    console.warn('Quota cooldown active, skipping scan');
    return false;
  }
  const timeSinceLastScan = now - pageCache.lastScanTime;
  const urlChanged = pageCache.currentUrl !== window.location.href;
  const contentChanged = hasPageChanged(currentText);
  return urlChanged || contentChanged || timeSinceLastScan > intervalMs;
};

const updatePageCache = (text, latest = {}) => {
  pageCache.currentUrl = window.location.href;
  pageCache.currentText = text;
  pageCache.lastScanTime = Date.now();
  if (typeof latest.overallScore === 'number') {
    pageCache.lastScore = latest.overallScore;
  }
  if (latest.breakdown) {
    pageCache.lastBreakdown = latest.breakdown;
  }
};

const analyzePage = async ({ bypassInterval = false } = {}) => {
  const liveDetectionEnabled = await new Promise((resolve) => {
    chrome.storage.local.get('liveDetectionEnabled', (result) => {
      resolve(result.liveDetectionEnabled !== false);
    });
  });

  if (!liveDetectionEnabled) {
    console.log('Live detection is disabled, skipping analysis');
    return;
  }

  console.log('Starting page analysis...');

  let pageText = document.body.innerText || '';
  pageText = pageText.replace(/\s+/g, ' ').trim();

  console.log('Extracted text length:', pageText.length);

  scanIntervalMs = await getConfiguredScanInterval();

  if (!bypassInterval && !shouldScanPage(pageText, scanIntervalMs)) {
    console.log('Page already scanned recently, skipping analysis');
    return;
  }

  if (!pageText || pageText.length < 50) {
    console.log('Insufficient text, sending zero score');
    try {
      if (chrome.runtime && chrome.runtime.id) {
        chrome.runtime.sendMessage({ type: 'toxicityScore', data: { overallScore: 0, breakdown: {} } }).catch(() => {});
      }
    } catch (e) {}
    updatePageCache(pageText);
    return;
  }

  const truncatedText = pageText.substring(0, 6000);
  console.log('Calling Gemini API with text sample...');
  const toxicityData = await getToxicityScore(truncatedText);
  console.log('Toxicity analysis result:', toxicityData);

  const host = window.location.hostname;
  const url = window.location.href;
  const timestamp = new Date().toISOString();
  const overallScore = toxicityData.overallScore;

  let classification = 'Suitable';
  if (overallScore > 70) classification = 'Extreme';
  else if (overallScore > 50) classification = 'High';
  else if (overallScore > 35) classification = 'Medium';
  else if (overallScore > 25) classification = 'Average';
  else if (overallScore > 10) classification = 'Okay';

  const attributes = {
    toxic: toxicityData.breakdown.toxic || 0,
    severe_toxic: toxicityData.breakdown.severe_toxic || 0,
    obscene: toxicityData.breakdown.obscene || 0,
    threat: toxicityData.breakdown.threat || 0,
    insult: toxicityData.breakdown.insult || 0,
    identity_hate: toxicityData.breakdown.identity_hate || 0,
    sexuality: toxicityData.breakdown.sexuality || 0,
    violence: toxicityData.breakdown.violence || 0,
    terrorism: toxicityData.breakdown.terrorism || 0,
  };

  chrome.storage.local.get(['history', 'recentDomains', 'liveData', 'emailSettings'], (result) => {
    const history = result.history || [];
    const recentDomains = result.recentDomains || {};
    const liveData = result.liveData || [];

    const historyEntry = {
      toxicity_score: overallScore,
      classification,
      host,
      url,
      timestamp,
      attributes,
    };
    history.unshift(historyEntry);
    if (history.length > 100) {
      history.splice(100);
    }

    recentDomains[host] = {
      toxicity_score: overallScore,
      classification,
      host,
      last_visited: timestamp,
    };

    const nowTs = Date.now();
    liveData.push({ time: nowTs, toxicity: overallScore });
    const twentyFourHoursAgo = nowTs - 24 * 60 * 60 * 1000;
    const filteredLiveData = liveData.filter((entry) => entry.time > twentyFourHoursAgo);

    chrome.storage.local.set({
      history,
      recentDomains,
      liveData: filteredLiveData,
    }, () => {
      console.log('Analysis saved to storage:', { host, overallScore, classification });

      const emailSettings = result.emailSettings || {};
      if (emailSettings.emailAlertsEnabled && emailSettings.toEmail) {
        const thresholds = emailSettings.categoryThresholds || {
          toxic: 70, severe_toxic: 50, obscene: 60, threat: 80,
          insult: 70, identity_hate: 75, sexuality: 65, violence: 80, terrorism: 90,
        };

        let shouldNotify = false;
        const triggeredCategories = [];

        for (const [category, value] of Object.entries(attributes)) {
          const threshold = typeof thresholds[category] === 'number' ? thresholds[category] : 100;
          if (value > threshold) {
            shouldNotify = true;
            triggeredCategories.push(`${category.replace(/_/g, ' ')}: ${Math.round(value)}%`);
          }
        }

        if (shouldNotify) {
          chrome.runtime.sendMessage({
            type: 'sendEmailNotification',
            data: {
              domain: host,
              overallScore,
              classification,
              triggeredCategories,
            },
          }).catch(() => {});
        }
      }
    });
  });

  try {
    if (chrome.runtime && chrome.runtime.id) {
      chrome.runtime.sendMessage({ type: 'toxicityScore', data: toxicityData }).catch(() => {});
      console.log('Toxicity message sent successfully');
    }
  } catch (e) {}

  updatePageCache(truncatedText, toxicityData);
};

setTimeout(() => {
  analyzePage();
}, 5000);

setInterval(() => {
  analyzePage();
}, 120000); // frequent scheduler; shouldScanPage respects configured interval

chrome.runtime.onMessage.addListener((message) => {
  if (message && message.type === 'forceAnalyze') {
    analyzePage({ bypassInterval: message.bypassInterval === true });
  }
});
